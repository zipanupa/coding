# Start of Settings
# Show the top X largest log files
$limit = 10
# End of Settings


$exclusions = @(
    [pscustomobject]@{Instance="EXAMPLE\INSTANCE";Database="ExDatabase"},
    [pscustomobject]@{Instance="EXAMPLE2";Database="EXAMPLEDb"}
)

$query = @"
SELECT DB_NAME(database_id) AS "Database", '{0}' as Instance,
Name AS Logical_Name,
Physical_Name, (size*8)/1024 SizeMB
FROM sys.master_files
where Physical_Name like '%.ldf'
"@



$results = @()
foreach ($Instance in $Instances)
{
    $q = $query -f $Instance.Server, $days
    $results += Invoke-sqlcmd $q -ServerInstance "$($Instance.Server)"
}
$cleanResults = @()
foreach ($result in $results)
{
    $excluded = $false
    foreach ($exclusion in $exclusions)
    {
        if (($result.Instance -eq $exclusion.Instance)-and($result.Database -eq $exclusion.Database))
        {
            $excluded = $true
        }
    }
    if (-not $excluded) 
    {
        $cleanResults += $result
    }
}
$cleanResults | Sort-Object -Property SizeMB -Descending | Select-Object Instance,Database,Logical_Name,Physical_Name,SizeMB -First $limit

$Title = "Top $limit largest log files"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Top $limit largest log files"
$Comments = "Top $limit largest log files"
$Display = "Table"
$PluginCategory = "SQL"
