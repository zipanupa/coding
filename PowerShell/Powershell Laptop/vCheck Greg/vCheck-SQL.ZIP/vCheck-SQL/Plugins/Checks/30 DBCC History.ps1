# Start of Settings
# DBCC Check Threshold
$days = 7
# End of Settings


$exclusions = @(
    [pscustomobject]@{Instance="EXAMPLE\INSTANCE";Database="ExDatabase"},
    [pscustomobject]@{Instance="EXAMPLE2";Database="EXAMPLEDb"}
)

$dbquery = "SELECT name from sys.databases"
$dbccquery = @"
IF OBJECT_ID('tempdb..#DBCCs') IS NOT NULL
			DROP TABLE #DBCCs;
		CREATE TABLE #DBCCs
			(
			  ID INT IDENTITY(1, 1)
					 PRIMARY KEY ,
			  ParentObject VARCHAR(255) ,
			  Object VARCHAR(255) ,
			  Field VARCHAR(255) ,
			  Value VARCHAR(255) ,
			  DbName NVARCHAR(128) NULL
			)
EXEC sp_MSforeachdb N'USE [?];
		INSERT #DBCCs
			(ParentObject,
			Object,
			Field,
			Value)
		EXEC (''DBCC DBInfo() With TableResults, NO_INFOMSGS'');
		UPDATE #DBCCs SET DbName = N''?'' WHERE DbName IS NULL;';
select '{0}' as Instance
	, DbName as 'Database'
	, CASE
		WHEN CAST(max(Value) as datetime) = 0 THEN 'Never'
		ELSE max( Value )
		END
		as 'LastDBCC'
    , max(Value) as Value
	 from #DBCCs
where Field = 'dbi_dbccLastKnownGood' and DbName <> 'tempdb' and DATEDIFF(dd, value, getdate()) > {1}
group by DbName
"@



$results = @()
foreach ($Instance in $Instances)
{
    $q = $dbccquery -f $Instance.Server, $days
    $results += Invoke-sqlcmd $q -ServerInstance "$($Instance.Server)"
}
$cleanResults = @()
foreach ($result in $results)
{
    $excluded = $false
    foreach ($exclusion in $exclusions)
    {
        if (($result.Instance -eq $exclusion.Instance)-and($result.Database -eq $exclusion.Database))
        {
            $excluded = $true
        }
    }
    if (-not $excluded) 
    {
        $cleanResults += $result
    }
}
$cleanResults | Sort-Object -Property Value | Select-Object Instance,Database,@{Name="Last Good DBCC Check";Expression={$_.LastDBCC}}

$Title = "Databases that have not had a healthy DBCC check in $days days"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Databases that have not had a healthy DBCC check in $days days"
$Comments = "This is a list of databases that have not had a healthy DBCC check in $days days"
$Display = "Table"
$PluginCategory = "SQL"
