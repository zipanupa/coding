# Start of Settings
# Indexe Fragmentation Threshold
$fragmentation = 15
# End of Settings

$exclusions = @(
    [pscustomobject]@{Instance="EXAMPLE\INSTANCE";Database="ExDatabase"},
    [pscustomobject]@{Instance="EXAMPLE2";Database="EXAMPLEDb"}
)

$query = @"
BEGIN
CREATE TABLE #INDEXFRAGINFO
(
[Database] nvarchar(128),
DatabaseID smallint,
full_obj_name nvarchar(384),
index_id INT,
[name] nvarchar(128),
index_type_desc nvarchar(60),
index_depth tinyint,
index_level tinyint,
[AVG_Fragmentation] float,
[Fragment_Count] bigint,
)

DECLARE @command VARCHAR(1000)
SELECT @command = 'Use [' + '?' + '] select ' + '''' + '?' + '''' + ' AS [Database],
DB_ID() AS DatabaseID,
QUOTENAME(DB_NAME(i.database_id), '+ '''' + '"' + '''' +')+ N'+ '''' + '.' + '''' +'+ QUOTENAME(OBJECT_SCHEMA_NAME(i.object_id, i.database_id), '+ '''' + '"' + '''' +')+ N'+ '''' + '.' + '''' +'+ QUOTENAME(OBJECT_NAME(i.object_id, i.database_id), '+ '''' + '"' + '''' +') as full_obj_name,
i.index_id,
o.name,
i.index_type_desc,
i.index_depth,
i.index_level,
i.avg_fragmentation_in_percent as [AVG Fragmentation],
i.fragment_count
from sys.dm_db_index_physical_stats(DB_ID(), default, default, default,'+ '''' + 'limited' + '''' +') as i
join sys.indexes o on o.object_id = i.object_id and o.index_id = i.index_id
where avg_fragmentation_in_percent >0 AND
i.INDEX_ID > 0 AND
i.Page_Count > 1000
order by i.database_id'

INSERT #INDEXFRAGINFO EXEC sp_MSForEachDB @command

SELECT '{0}' as Instance, * FROM #INDEXFRAGINFO
Where DatabaseID > 4 and [AVG_Fragmentation] > {1}

DROP TABLE #INDEXFRAGINFO

END
GO

"@

$results = @()
foreach ($Instance in $Instances)
{
  $q = $query -f $Instance.Server, $fragmentation
  $results += Invoke-sqlcmd $q -ServerInstance "$($Instance.Server)"
}
$cleanResults = @()
foreach ($result in $results)
{
  $excluded = $false
  foreach ($exclusion in $exclusions)
  {
    if (($result.Instance -eq $exclusion.Instance) -and ($result.Database -eq $exclusion.Database))
    {
      $excluded = $true
    }
  }
  if (-not $excluded)
  {
    $cleanResults += $result
  }
}
$cleanResults | Sort-Object -Property AVG_Fragmentation -Descending | select Instance, Database, full_obj_name, AVG_Fragmentation, Fragment_Count

$Title = "Indexes with an average fragmentation over $fragmentation%"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Indexes with an average fragmentation over $fragmentation%"
$Comments = "This is a list of indexes that have an average fragmentation over $fragmentation%"
$Display = "Table"
$PluginCategory = "SQL"
