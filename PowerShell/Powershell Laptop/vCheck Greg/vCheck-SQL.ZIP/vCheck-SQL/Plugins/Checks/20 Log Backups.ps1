# Start of Settings 
# Log Backup threshold
$mins = 90
# End of Settings

$exclusions = @(
    [pscustomobject]@{Instance="EXAMPLE\INSTANCE";Database="ExDatabase"},
    [pscustomobject]@{Instance="EXAMPLE2";Database="EXAMPLEDb"}
)

$query = @"
SELECT sdb. Name AS "Database" , '{0}' as Instance ,
    COALESCE( MAX(bus .backup_finish_date), null) AS LastLogBackUpTime
    FROM sys.databases sdb
    LEFT OUTER JOIN msdb.dbo .backupset bus ON bus.database_name = sdb. name and bus.type = 'L'
        WHERE sdb. recovery_model_desc <> 'SIMPLE'
        AND sdb.Name <> 'model'
    GROUP BY sdb. Name
        HAVING DATEDIFF (mi, COALESCE( MAX(bus .backup_finish_date), 0), getdate()) > {1}
"@


$results = @()
$sqlServers = $InstanceList.split(",")
foreach ($sqlServer in $sqlServers)
{
    $sqlServer = $sqlServer.Trim(' "')
    $q = $query -f $sqlServer,$mins
    $results += Invoke-sqlcmd $q -ServerInstance "$sqlServer" 
}
$cleanResults = @()
foreach ($result in $results)
{
    $excluded = $false
    foreach ($exclusion in $exclusions)
    {
        if (($result.Instance -eq $exclusion.Instance)-and($result.Database -eq $exclusion.Database))
        {
            $excluded = $true
        }
    }
    if (-not $excluded) 
    {
        $cleanResults += $result
    }
}

$cleanResults | Sort-Object -Property LastLogBackupTime | Select-Object Instance,Database,@{Name="Last Log Backup";Expression={If ("$($_.LastLogBackupTime)" -eq "") { "Never" } else { $($_.LastLogBackupTime) }}}

$Title = "Databases without log backup's in the last $mins minutes"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Databases without log backup's in the last $mins minutes"
$Comments = "This is a list of databases that have not had a log backup in the last $mins minutes. (Excluding databases using the SIMPLE recovery model)."
$Display = "Table"
$PluginCategory = "SQL"

