﻿# Start of Settings 
# Enter a test string
# End of Settings

#$InstanceList = "WFWLOSQ2, WFWDC2SQL02\SQL1, WFWDC1SQL02\SQL1"

#Manually import the sqlps module to avoid this issue http://stackoverflow.com/questions/24164826/powershell-invoke-sqlcmd-switches-into-sqlps-session
push-location
import-module sqlps -disablenamechecking
pop-location

$OSVersions = @{
    "5.0" = "Windows 2000"
    "5.2" = "Windows Server 2003 (R2)"
    "6.0" = "Windows Server 2008"
    "6.1" = "Windows Server 2008 R2"
    "6.2" = "Windows Server 2012"
    "6.3" = "Windows Server 2012 R2"
}

$SQLVersions = @{
    "8.00" = "SQL Server 2000"
    "9.00" = "SQL Server 2005"
    "10.00" = "SQL Server 2008"
    "10.50" = "SQL Server 2008 R2"
    "11.00" = "SQL Server 2012"
    "11.0" = "SQL Server 2012"
    "12.0" = "SQL Server 2014"
    "13.0" = "SQL Server 2016"
}

# Add pretty icons
Add-ReportResource -cid "Error" -Type "SystemIcons" -ResourceData "Error"
Add-ReportResource -cid "OK" -Type "base64" -ResourceData "png|iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAI5ElEQVR42p1XC1BU1xn+7j7YXR4LLCu6CwiKIuBbVBRj8YE0iokEWydpO2k64yRtmqRTzWTsKxmbxlTHWCdN00yeTowdkzRFi4yKWlTwgW80LIigyAILy0seK/u69/Y/Z5cra6yPnp3/nrv3cb7v/85//v9cAQ/ZNE8hl7r5ZDPJ0smSyKLJ+sjsZHVkF8lO+Ytx7GHHFR4AGkHdD8mKrAmWlYlJCYLVaoF5VByio43QG/RwD7nR19ePrs5utLU50GJvldvsjoNQ4Ut672si4/q/CBD4MurWTkhLXZOZmY7ktCQIagE6lR6RmkgYtTHQawxw+4fQ7+vDoL8fHskDWZRxs94Om60ODbbGfVDjr/49KHskAgT+Qpw5bsPMWdNS0mekQavRwWIYg2htrPKMTD+B92wQgf9njZFxDLXB5/ei7lI9Lpypdva092z278e2hyJA4OvHJif9cV7O3PAxKfEYrR8Dsy5egb3ziqyA333Ozro8TnS429He5MSpyipfc13LVrEMv70vAeY5gW9buGRB+CiLGenGzBEPfFcsOXgUlONIegFaV/tt6HR04fjhSl/zty1vif/BxnsSYHNOsn+4dNmiFOs4CzIIfPh2wKeA6PfyfySVe9GsJRJtNxw4VFLe33O952XxBD4PIRCM9k/z8hevycxKR2b0FLqhUgYO9QtBOv8rgmU03WxCq7MNer0eWVOzINGvtu9b2M7X4dDX5dXydayUmtAyksBzFO2fPV6YB0uENTjnsgI0DDkstixL/Loky4rfggBO2tvnQ864HGSYpqHtdguu9dfB7mqmmOhEu6sNB/YcxrXyxu3iGaxjLw8T+PeThQVPpGamYpIxXYEUQmYZEGV/wCSJe8WISEECakEF320/ViSvxHjTRGhVYURKQIvLjrLWfXy8OpqKRtt17P2s9KZ4FN+ji80Cy3CUZMpX/3iVkBiVjBha37IicACaeeqTffBLfjLq6VwkcFEWFeHV5P0k9RQUTi4iYJVynalwoKWEj9fn64V9oBnf7NqLliOO16VavMkIbJg7b/bb8xbPobmfGhLLjIhEID4C9lKS8UpeboyEj0waoYC3VcTbBZuho+Q0su25+U/0eLqUEK7pu4zT5Wdxeve5U9JFrGAEviwsemLNxIxUTIhKC5ltBsAAWYbziB64xSHqvZyMP6gIjwWvhHVTf4M006QQ8JPOClzqPocwmg6VoObPNgxcRUNtI4o/LGkWKwIEqte+8Nw06+gEWMMTR/gO8tJLoG4OPEQpd0gMGFeDiDDvVT4VViWvRmHqD0LAB32DeK92G/RqPXTqMJ7CWWulKWnraMVH23b0U2J6mhHoWf/aK7ENQw3Is+RT8Og4CRZsbvL6Sv0VOHucCIvQIjrRyD1najBVBFHA6FuJeLfofahV6hACb176PY+RcE04DOpwIqEnRX047DiECYYJeGfTuz5/CV5mBMTfvfGa6u+172G2eS5yRi2kvG/h0tdU1+Lny17kyjSSdDsufYrusE6uhkjy69wGfJC3A2aDWQFm0/JK1fO0KtS8aEVoIxFOBFiNONt9Bue6qvCLjJfw1sYtMlXKjYoC/7B/waVOihiLGbFZyIjOwOqUZ5BA/7UU4b2eXh54vyxfCyFCQHd7N16a82sUTVgT4vnrFzfQ2r9K1TKKCETx+W9y3aBEZOMrQq824EdJP2EK+EmB7UoMVLiPwjnUoQw0NiIFHy/YiRmmrEBU0FLsdfeg39uHF/evRVpUOv5S8LeQ5HuwtRTv1LyNKK2R54gB30CgIA05lGfiDaOxUL+IxcAgxcBWZRU4zW2ovWUL8WaJZRk2Z21HcuQ4hUTnbScutJzHotQltB/QK892up1YenA+nwKWM1z+QX5+d8uIyUR8lxXFH5Q4qCZsVPKANTsexxzl33lhtjkbu3P3kqRG/p+tfJdnEFE6Y8hzuQfmkAM1eFDLtSxGW5UTp3eds0mX8aqSCQuezhcOtu/nst3dpptm4qtF+xAbdmdDQnLwRM6mYGvNJmy58qcHgkdRXHx/zHKU7i6DvdhxRG7FrwK1YBX2P1lU8PiA5RYljgv3fHlq7HQiUYI4nTnkOvN6ycFsnpof1GbEzUKUIwZ7PyntFI/zPeMfQqrhYwXzUNF1jFJnd8iLQjDO0o2TUZZfwdc0F4F+2aVT0DrYBH/wygiBQppJF4eF5lxUlp5GfXHjRakeTLJ/3dkP+LE7b8XilZEZeoqFowHg4EEIHHh1+9n45/HMuGf5/a+ad+HzGx/xYiVT0hGl4NQEuQzvExmZXMsiDNa6ceiL8g7xLErh5Tuj5js7okLkm2JNO/OWL47vie3E+a6zHJB5rwr2Gg0ru1qoKelpVBq6zjJmIPn4/QyO9YHVwncKQRlmxc2FqdeMsj1H3F3He8/Kdmyhy6UY3g8oJJZjXdLExD8vWDJf2x3p5CRUhMIsjPUaLVU7NU2BFmFqDScoUcr2ketDVBsYuES7YTYdkiRzz7NM2TC5RqHyyAnxRpndRiV4J93+hKxHUXlkU+dj09j0xFdzFs7T+uPdsFGQ9fo7odOqyMJo7YfBQNt0vVZP+VEI1AZCdvmpQvp8PAd4SY1RWgvf2qmdOlRWnBQbDt+4RsuOef0+2XUlvu4VreqleCMuMW7dnJyZxuQpSejwtqPJ0wA3blFx0SEiLJwI6IiAipdsN4Hf9lPV9HkQqY7DeEM6rNoE0FYcJ0+cdrdWOa6Jl/jHyccIfMLhvgQ4icfwLAxYNzk7ffq0KVORNNEKl+TCgDQAt3wbHnmQ+l7ohVgYVEYYhAgYNdGIUcXA0dRBVbQGZyqrOvwNqJdsYFuib0Z6/kACrKnGI1FlwXpE4alJMycmp6akYlxiCqxmC0xGE/Q6+jb0uNE70EcluwPNDjtutFxH9ZXLnVILWvzV9LHqQjENdXJ4zh+JwIhnktRZ+CnCsVxlRoLGSI5GktMaaNjqk12k/gAG5B70Sh1wSDWopXdYXj+HwJezfL/BH6XFkCWQjQ3aGLJIskGydrLmoLWS3XqYAf8LHVgyvLhECXAAAAAASUVORK5CYII="


$Instances = @()
ForEach ($InstanceStr in $InstanceList.split(","))
{
    $InstanceStr = $InstanceStr.Trim(' "')
    $NewInstance = New-Object -TypeName PSObject -Property @{        
        "Server" = $InstanceStr
        "HostName" = $InstanceStr.Split("\")[0]
        "InstanceName" = $InstanceStr.Split("\")[1]
        "OSVersionNum" = ""
        "OSVersionDesc" = ""
        "SQLVersionShortNum" = ""
        "SQLVersionFullNum" = ""
        "SQLVersionDesc" = ""
        "SQLVersionLevel" = ""
        "SQLEdition" = ""
        "SQLAgentStatus" = ""
    }    
    $Instances += $NewInstance
}

$osquery = @"
SELECT windows_release
    , windows_service_pack_level
    , windows_sku
    , os_language_version
    FROM sys.dm_os_windows_info;
"@

$sqlquery = @"
SELECT SERVERPROPERTY ('productversion') as productversion
    , SERVERPROPERTY ( 'productlevel') as productlevel
    , SERVERPROPERTY ('edition') as edition
"@
$agentquery = @"
xp_servicecontrol 'querystate', 'SQLSERVERAGENT'
"@
ForEach ($Instance in $Instances)
{
    $results = Invoke-Sqlcmd -query $osquery -ServerInstance "$($Instance.Server)"
    $Instance.OSVersionNum = $results.windows_release
    $Instance.OSVersionDesc = $OSVersions.Get_Item($results.windows_release)
    $results = Invoke-Sqlcmd -query $sqlquery -ServerInstance "$($Instance.Server)"
    $Instance.SQLVersionFullNum = $results.productversion
    $Instance.SQLVersionShortNum = $results.productversion.Split(".")[0] + "." + $results.productversion.Split(".")[1]
    $Instance.SQLVersionLevel = $results.productlevel
    $Instance.SQLEdition = $results.edition
    $Instance.SQLVersionDesc = $SQLVersions.Get_Item($Instance.SQLVersionShortNum)
    $results = Invoke-sqlcmd -query $agentquery -ServerInstance "$($Instance.Server)"
    $Instance.SQLAgentStatus = $results.'Current Service State'
}

$Instances | Sort-Object -Property Server | Select-Object Server, @{Name="SQL Agent Status";Expression={$_.SQLAgentStatus}}, @{Name="SQL Edition";Expression={"$($_.SQLVersionDesc) $($_.SQLEdition) $($_.SQLVersionLevel) ($($_.SQLVersionFullNum))"}}, @{Name="Operating System";Expression={$_.OSVersionDesc}}


$Title = "General Information"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "General Information"
$Comments = ""
$Display = "Table"
$PluginCategory = "SQL"

$TableFormat = @{"SQL Agent Status" = @(@{ "-ne `"Running.`""     = "Cell,cid|Error|16x16"; },
                               @{ "-eq `"Running.`""    = "Cell,cid|OK|16x16" })
                 }
