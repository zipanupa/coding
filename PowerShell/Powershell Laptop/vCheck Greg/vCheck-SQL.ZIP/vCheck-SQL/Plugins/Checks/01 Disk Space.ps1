# Start of Settings
# Show drives with less than X% free space (Expressed as decimal)
$freePercent = 0.30
# End of Settings

$exclusions = @(
    [pscustomobject]@{Server="EXAMPLE\INSTANCE";DriveName="D:\"},
    [pscustomobject]@{Server="EXAMPLE2";DriveName="C:\"}
)

$results = @()
foreach ($Instance in $Instances) {
    Write-Host "trying  $($Instance.HostName)"
    $results += get-WmiObject win32_volume -ComputerName $Instance.HostName | ?{$_.DriveType -eq 3} | select @{Name="Server";Expression={$Instance.HostName}},FreeSpace,Capacity,Name 
}

$cleanResults = @()
foreach ($result in $results)
{
    $excluded = $false
    foreach ($exclusion in $exclusions)
    {
        if (($result.Server -eq $exclusion.Server)-and($result.Name -eq $exclusion.DriveName))
        {
            $excluded = $true
        }
    }
    if (-not $excluded) 
    {
        $cleanResults += $result
    }
}
$freePercentText = "{0:p}" -f $freePercent
$cleanResults | ?{($_.Name -ne "D:\") -and ($_.Capacity -gt 1GB) -and (($_.FreeSpace/$_.Capacity) -le $freePercent)} | sort-object @{Expression={$($_.FreeSpace/$_.Capacity)}} |select Server, Name, @{Name="FreeSpace (GB)"; Expression={[math]::Round($_.FreeSpace/1GB)}}, @{Name="Capacity (GB)"; Expression={[math]::Round($_.Capacity/1GB)}}, @{Name='Percent Free'; Expression={[math]::Round(100 * $($_.FreeSpace/$_.Capacity), 1)}}


$Title = "Drives with less than $freePercentText free space"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Drives with less than $freePercentText free space"
$Comments = "This is a list of disks which have less than $freePercentText of capacity remaining. Excludes D:\ and drives with less than 1GB total capacity. Data is gathered using WMI"
$Display = "Table"
$PluginCategory = "SQL"

$TableFormat = @{"Percent Free" = @(@{ "-le 10"     = "Row,class|critical"; },
								   @{ "-le 25"     = "Row,class|warning" })			   
				}
