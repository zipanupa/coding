# Start of Settings 
# Full Backup threshold
$hours = 24
# End of Settings

$exclusions = @(
    [pscustomobject]@{Instance="EXAMPLE\INSTANCE";Database="ExDatabase"},
    [pscustomobject]@{Instance="EXAMPLE2";Database="EXAMPLEDb"}
)

$query = @"
SELECT sdb.Name AS "Database", '{0}' as Instance ,
    COALESCE( MAX(bus .backup_finish_date), null) AS LastFullBackupTime
    FROM sys.sysdatabases sdb
    LEFT OUTER JOIN msdb.dbo .backupset bus ON bus.database_name = sdb. name and bus.type = 'D'
    WHERE sdb.Name <> 'tempdb'
    GROUP BY sdb. Name
        HAVING DATEDIFF (hh, COALESCE( MAX(bus .backup_finish_date), 0), getdate()) > {1}
"@


$results = @()
$sqlServers = $InstanceList.split(",")
foreach ($sqlServer in $sqlServers)
{
    $sqlServer = $sqlServer.Trim(' "')
    $q = $query -f $sqlServer,$hours
    $results += Invoke-sqlcmd $q -ServerInstance "$sqlServer" 
}
$cleanResults = @()
foreach ($result in $results)
{
    $excluded = $false
    foreach ($exclusion in $exclusions)
    {
        if (($result.Instance -eq $exclusion.Instance)-and($result.Database -eq $exclusion.Database))
        {
            $excluded = $true
        }
    }
    if (-not $excluded) 
    {
        $cleanResults += $result
    }
}
$cleanResults | Sort-Object -Property LastFullBackupTime | Select-Object Instance,Database,@{Name="Last Full Backup";Expression={If ("$($_.LastFullBackupTime)" -eq "") { "Never" } else { $($_.LastFullBackupTime) }}}

$Title = "Databases without full backup's in the last $hours hours"
$Author = "Greg Jebb"
$PluginVersion = 1
$Header = "Databases without full backup's in the last $hours hours"
$Comments = "This is a list of databases that have not had a full backup in the last $hours hours. (Excluding tempdb)."
$Display = "Table"
$PluginCategory = "SQL"
